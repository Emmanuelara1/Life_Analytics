
import React from "react";

function HomePage() {
  return (
    <div className="home-page">
      <h1>Welcome to the Human Genome Project</h1>
      <p>
        The Human Genome Project (HGP) is one of the greatest scientific feats in
        history. This website aims to explore genomic data and life analytics based
        on the human genome.
      </p>
    </div>
  );
}

export default HomePage;
