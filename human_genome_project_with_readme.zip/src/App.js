
import React from "react";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import Header from "./components/Header";
import HomePage from "./components/HomePage";
import GenomeAnalyticsPage from "./components/GenomeAnalyticsPage";
import LifeAnalyticsPage from "./components/LifeAnalyticsPage";
import "./App.css";

function App() {
  return (
    <Router>
      <div className="App">
        <Header />
        <Switch>
          <Route path="/" exact component={HomePage} />
          <Route path="/genome-analytics" component={GenomeAnalyticsPage} />
          <Route path="/life-analytics" component={LifeAnalyticsPage} />
        </Switch>
      </div>
    </Router>
  );
}

export default App;
